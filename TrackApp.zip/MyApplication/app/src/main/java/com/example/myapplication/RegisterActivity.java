package com.example.myapplication;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


public class RegisterActivity extends AppCompatActivity {

    Button RegisterButton, CancelButton;
    EditText NameHolder,  PasswordHolder;
    Boolean EmptyHolder;
    SQLiteDatabase db;
    UsersSQLiteHandler handler;
    String F_Result = "Not_Found";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        NameHolder = findViewById(R.id.editTextPersonName);
        PasswordHolder = findViewById(R.id.editTextPassword);
        RegisterButton = findViewById(R.id.regSignupButton);
        CancelButton = findViewById(R.id.regCancelButton);
        handler = new UsersSQLiteHandler(this);

        // Adding click listener to register
        RegisterButton.setOnClickListener(view -> {
            String message = CheckEditTextNotEmpty();

            if (!EmptyHolder) {
                // Empty editText fields after done inserting in database
                EmptyEditTextAfterDataInsert();
            } else {
                // Display toast message if any field is empty and focus the field
                Toast.makeText(this, message, Toast.LENGTH_LONG).show();
            }
        });

        // Adding click listener to addCancelButton
        CancelButton.setOnClickListener(view -> {
            // Going back to LoginActivity after cancel Register
            startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
            this.finish();
        });

    }

    // Register new user into database
    public void InsertUserIntoDatabase(){
        String name = NameHolder.getText().toString().trim();
        String pass = PasswordHolder.getText().toString().trim();

        User user = new User(name, pass);
        handler.createUser(user);

        // Printing toast message after done inserting.
        Toast.makeText(RegisterActivity.this,"User Registered Successfully", Toast.LENGTH_LONG).show();

        // Going back to LoginActivity after register success message
        startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
        this.finish();
    }

    // Checking item description is not empty
    public String CheckEditTextNotEmpty() {
        // Getting value from fields and storing into string variable
        String message = "";
        String name = NameHolder.getText().toString().trim();
        String pass = PasswordHolder.getText().toString().trim();

        if (name.isEmpty()) {
            NameHolder.requestFocus();
            EmptyHolder = true;
            message = "User Name is Empty";
        } else if (pass.isEmpty()){
            PasswordHolder.requestFocus();
            EmptyHolder = true;
            message = "User Password is Empty";
        } else {
            EmptyHolder = false;
        }
        return message;
    }

    // Check if user email already exists in database
    public void CheckUserAlreadyExists(){
        String email = NameHolder.getText().toString().trim();
        db = handler.getWritableDatabase();

        // Adding search user query to cursor
        Cursor cursor = db.query(UsersSQLiteHandler.TABLE_NAME, null, " " + UsersSQLiteHandler.COLUMN_1_NAME + "=?", new String[]{email}, null, null, null);

        while (cursor.moveToNext()) {
            if (cursor.isFirst()) {
                cursor.moveToFirst();
                // If user exists then set result variable value as User Found
                F_Result = "User Found";
                // Closing cursor.
                cursor.close();
            }
        }
        handler.close();

        // Calling method to check final result and insert data into SQLite database
        CheckFinalCredentials();
    }

    // Check login credentials are correct
    public void CheckFinalCredentials(){
        // Checking whether name is already in database
        if(F_Result.equalsIgnoreCase("Name Found"))
        {
            // If user is exists then toast msg will display
            Toast.makeText(RegisterActivity.this,"Name Already Exists",Toast.LENGTH_LONG).show();
        }
        else {
            // If user doesn't exists then user registration details will entered to SQLite database
            InsertUserIntoDatabase();
        }
        F_Result = "Not_Found" ;
    }

    // Empty edittext after done inserting in database
    public void EmptyEditTextAfterDataInsert(){
        NameHolder.getText().clear();

        PasswordHolder.getText().clear();
    }

}

